package com.lti.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lti.entities.Bids;
import com.lti.entities.SellRequest;
import com.lti.exceptions.GenericException;
@Repository
@Scope("singleton")
public class BidderDaoImpl implements BidderDao {
	@PersistenceContext
	private EntityManager manager;
	@Transactional
	@Override
	public List<SellRequest> getActiveAuctions() throws GenericException {
		// TODO Auto-generated method stub
		Query qry=manager.createNamedQuery("allActiveAuctions");
/*		System.out.println(qry);
		System.out.println("I am here");*/
		return qry.getResultList();
	}
	
	@Transactional
	@Override
	public List<SellRequest> getFilterActiveAuctions(String str) throws GenericException {
		// TODO Auto-generated method stub
		 Query qry=manager.createNamedQuery("FilterActiveAuctions");
		qry.setParameter("cropName", str);
		return qry.getResultList();
	}
	
	
	@Transactional
	@Override
	public List<SellRequest> setBid(int sellId) throws GenericException {
		// TODO Auto-generated method stub
		Query qry=manager.createNamedQuery("currentSellRequest");
		qry.setParameter("sellId", sellId);
		return qry.getResultList();
	}

	@Override
	public Integer createNewBidId() throws GenericException {
		// TODO Auto-generated method stub
		Query query = manager.createNamedQuery("maxBidId");
		Integer id1=(Integer)query.getSingleResult();
		return id1+1;
	}
	@Transactional
	@Override
	public Bids addBids(Bids bids) throws GenericException {
		// TODO Auto-generated method stub
		manager.persist(bids);
		return bids;
		
	}
	@Transactional
	@Override
	public SellRequest getSellRequestDetails(int sellId) throws GenericException {
		// TODO Auto-generated method stub
		Query qry=manager.createNamedQuery("allDetails");
		qry.setParameter("sellId",sellId);
		return (SellRequest) qry.getSingleResult();
		
	}
	
	
	

}

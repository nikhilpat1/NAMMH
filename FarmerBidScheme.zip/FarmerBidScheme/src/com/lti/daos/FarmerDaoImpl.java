package com.lti.daos;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.entities.CropDetails;
import com.lti.entities.SellRequest;
import com.lti.exceptions.GenericException;

@Repository
@Scope("singleton")

public class FarmerDaoImpl implements FarmerDao{

	@PersistenceContext
	private EntityManager manager;

	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public CropDetails insertCropDetails(CropDetails cropDetails) throws GenericException {
		// TODO Auto-generated method stub
		System.out.println(cropDetails);
		
		manager.persist(cropDetails);
	
		System.out.println("Done");
		return cropDetails;
	}
	
	public Integer createNewCropId() throws GenericException{
		//Query query=manager.createQuery("select max(empId) from Employees");
		Query query = manager.createNamedQuery("maxCropId");
		Integer id=(Integer)query.getSingleResult();
		return id+1;
		//Query qry=manager.createQuery("select max(crop_id) from crop_details");
	}

	@Override
	public Integer createNewSellId() throws GenericException {
		// TODO Auto-generated method stub
		Query query = manager.createNamedQuery("maxSellId");
		Integer id1=(Integer)query.getSingleResult();
		return id1+1;
	}
	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public SellRequest insertSellDetails(SellRequest sellRequest) throws GenericException {
		// TODO Auto-generated method stub
		System.out.println(sellRequest);
		manager.persist(sellRequest);
		System.out.println("Done");
		return sellRequest;
	}
	
	
}

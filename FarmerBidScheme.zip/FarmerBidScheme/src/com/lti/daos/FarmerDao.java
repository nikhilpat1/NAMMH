package com.lti.daos;

import com.lti.entities.CropDetails;
import com.lti.entities.SellRequest;
import com.lti.exceptions.GenericException;

public interface FarmerDao  {
	public CropDetails insertCropDetails(CropDetails cropDetails) throws GenericException;
	public Integer createNewCropId() throws GenericException;
	public Integer createNewSellId() throws GenericException;
	public SellRequest insertSellDetails(SellRequest sellRequest) throws GenericException;

}

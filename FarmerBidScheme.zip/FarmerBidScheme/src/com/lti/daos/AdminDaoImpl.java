package com.lti.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.entities.Bids;
import com.lti.entities.SellRequest;
import com.lti.exceptions.GenericException;
@Repository
@Scope("singleton")
public class AdminDaoImpl implements AdminDao {

	@PersistenceContext
	private EntityManager manager;

	
	@Override
	public List<SellRequest> getUnapprovedSellRequest() throws GenericException {
		// TODO Auto-generated method stub
		Query qry=manager.createNamedQuery("allUnapprovedSellRequest");
		return qry.getResultList();
	}
	@Transactional
	@Override
	public SellRequest approveSellRequest(int sellId) throws GenericException {
		// TODO Auto-generated method stub
		//Query q = manager.createNamedQuery("update");
		SellRequest sellrequest1 = manager.find(SellRequest.class, sellId);
		sellrequest1.setStatus("Approved");		
		manager.persist(sellrequest1);
		return sellrequest1;				
	}
	
	@Transactional	
	@Override
	public List<Bids> getUnapprovedBidsRequest() throws GenericException {
		// TODO Auto-generated method stub
		Query qry=manager.createNamedQuery("allUnapprovedBidsRequest");
		return qry.getResultList();
	}
	
	@Transactional	
	@Override
	public Bids approveBidStatus(int bidId) throws GenericException {
		// TODO Auto-generated method stub
		Bids bids = manager.find(Bids.class, bidId);
		bids.setStatus("Approved");		
		manager.persist(bids);
		return bids;				
	}

	
}
	

	
	

package com.lti.daos;

import java.util.List;

import com.lti.entities.Bids;
import com.lti.entities.SellRequest;
import com.lti.exceptions.GenericException;

public interface AdminDao {
	public List<SellRequest> getUnapprovedSellRequest() throws GenericException;
	public SellRequest approveSellRequest(int sellId) throws GenericException;
	public List<Bids> getUnapprovedBidsRequest() throws GenericException; 
	public Bids approveBidStatus(int bidId) throws GenericException ;


	
 }

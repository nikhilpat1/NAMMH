package com.lti.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@NamedQueries({
	@NamedQuery(name="maxCropId", query="select max(id) from CropDetails"),
})
@Entity
@Table(name="crop_details")
public class CropDetails {

	private int id;
	private String cropType;
	private String cropName;
	private String fertilizerType;
	private double soilPh;
	//private int farmerId;
	public CropDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
/*	public CropDetails(int id, String cropType, String cropName, String fertilizerType, double soilPh,
			int farmerId) {
		super();
		this.id = id;
		this.cropType = cropType;
		this.cropName = cropName;
		this.fertilizerType = fertilizerType;
		this.soilPh = soilPh;
		this.farmerId = farmerId;
	}*/
	
	
	@Id
	@Column(name="CROP_ID")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Column(name="CROP_TYPE")
	public String getCropType() {
		return cropType;
	}
	public void setCropType(String cropType) {
		this.cropType = cropType;
	}
	@Column(name="CROP_NAME")
	public String getCropName() {
		return cropName;
	}
	public void setCropName(String cropName) {
		this.cropName = cropName;
	}
	@Column(name="FERTILIZER_TYPE")
	public String getFertilizerType() {
		return fertilizerType;
	}
	public void setFertilizerType(String fertilizerType) {
		this.fertilizerType = fertilizerType;
	}
	@Column(name="SOIL_PH")
	public double getSoilPh() {
		return soilPh;
	}
	public void setSoilPh(double soilPh) {
		this.soilPh = soilPh;
	}

	List<SellRequest> sellrequest;
	
	@OneToMany(mappedBy="cropdetails")
	public List<SellRequest> getSellrequest() {
		return sellrequest;
	}
	public void setSellrequest(List<SellRequest> sellrequest) {
		this.sellrequest = sellrequest;
	}
	
	private FarmerInfo farmerinfo;
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="FARMER_ID")
	public FarmerInfo getFarmerinfo() {
		return farmerinfo;
	}
	public void setFarmerinfo(FarmerInfo farmerinfo) {
		this.farmerinfo = farmerinfo;
	}


	@Override
	public String toString() {
		return "CropDetails [id=" + id + ", cropType=" + cropType + ", cropName=" + cropName + ", fertilizerType="
				+ fertilizerType + ", soilPh=" + soilPh + ", farmerinfo=" + farmerinfo
				+ "]";
	}


	
	
	
	

	
	
	

}

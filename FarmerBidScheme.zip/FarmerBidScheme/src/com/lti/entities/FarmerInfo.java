package com.lti.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Farmer")
public class FarmerInfo {
	
	private int farmerId;
	private String farmerName;
	private String farmerAddress;
	private long contactNo;
	private String emailId;
	private String farmerAccountNo;
	private long aadhaarNo;
	private String panNo;
	
	public FarmerInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public FarmerInfo(int farmerId, String farmerName, String farmerAddress, long contactNo, String emailId,
			String farmerAccountNo, long aadhaarNo, String panNo) {
		super();
		this.farmerId = farmerId;
		this.farmerName = farmerName;
		this.farmerAddress = farmerAddress;
		this.contactNo = contactNo;
		this.emailId = emailId;
		this.farmerAccountNo = farmerAccountNo;
		this.aadhaarNo = aadhaarNo;
		this.panNo = panNo;
	}

	@Id
	@Column(name="FARMER_ID")
	public int getFarmerId() {
		return farmerId;
	}
	public void setFarmerId(int farmerId) {
		this.farmerId = farmerId;
	}
	
	@Column(name="FARMER_NAME")
	public String getFarmerName() {
		return farmerName;
	}
	public void setFarmerName(String farmerName) {
		this.farmerName = farmerName;
	}
	
	@Column(name="FARMER_ADDRESS")
	public String getFarmerAddress() {
		return farmerAddress;
	}
	public void setFarmerAddress(String farmerAddress) {
		this.farmerAddress = farmerAddress;
	}
	
	@Column(name="CONTACT_NO")
	public long getContactNo() {
		return contactNo;
	}
	public void setContactNo(long contactNo) {
		this.contactNo = contactNo;
	}
	
	@Column(name="EMAIL_ID")
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	@Column(name="FARMER_ACC_NO")
	public String getFarmerAccountNo() {
		return farmerAccountNo;
	}
	public void setFarmerAccountNo(String farmerAccountNo) {
		this.farmerAccountNo = farmerAccountNo;
	}
	
	@Column(name="AADHAAR_NO")
	public long getAadhaarNo() {
		return aadhaarNo;
	}
	public void setAadhaarNo(long aadhaarNo) {
		this.aadhaarNo = aadhaarNo;
	}
	
	@Column(name="PAN_NO")
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	
	List<CropDetails> cropdetails;
	@OneToMany(mappedBy="farmerinfo")
	
	public List<CropDetails> getCropdetails() {
		return cropdetails;
	}


	public void setCropdetails(List<CropDetails> cropdetails) {
		this.cropdetails = cropdetails;
	}


	@Override
	public String toString() {
		return "FarmerInfo [farmerId=" + farmerId + ", farmerName=" + farmerName + ", farmerAddress=" + farmerAddress
				+ ", contactNo=" + contactNo + ", emailId=" + emailId + ", farmerAccountNo=" + farmerAccountNo
				+ ", aadhaarNo=" + aadhaarNo + ", panNo=" + panNo + "]";
	}
	
	

	
	
	

}

package com.lti.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Bidder")
public class BidderInfo {
	
	private String bidderId;
	private String bidderName;
	private String bidderAddress;
	private int contactNo;
	private String emailId;
	private String bidderAccountNo;
	private int aadhaarNo;
	private String panNo;
	private String licenseNo;
	
	
	
	public BidderInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	public BidderInfo(String bidderId, String bidderName, String bidderAddress, int contactNo, String emailId,
			String bidderAccountNo, int aadhaarNo, String panNo, String licenseNo) {
		super();
		this.bidderId = bidderId;
		this.bidderName = bidderName;
		this.bidderAddress = bidderAddress;
		this.contactNo = contactNo;
		this.emailId = emailId;
		this.bidderAccountNo = bidderAccountNo;
		this.aadhaarNo = aadhaarNo;
		this.panNo = panNo;
		this.licenseNo = licenseNo;
	}

	@Id
	@Column(name="BIDDER_ID")
	public String getBidderId() {
		return bidderId;
	}
	public void setBidderId(String bidderId) {
		this.bidderId = bidderId;
	}
	@Column(name="BIDDER_NAME")
	public String getBidderName() {
		return bidderName;
	}
	public void setBidderName(String bidderName) {
		this.bidderName = bidderName;
	}
	@Column(name="BIDDER_ADDRESS")
	public String getBidderAddress() {
		return bidderAddress;
	}
	public void setBidderAddress(String bidderAddress) {
		this.bidderAddress = bidderAddress;
	}
	
	@Column(name="CONTACT_NO")
	public int getContactNo() {
		return contactNo;
	}
	public void setContactNo(int contactNo) {
		this.contactNo = contactNo;
	}
	@Column(name="EMAIL_ID")
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	@Column(name="BIDDER_ACC_NO")
	public String getBidderAccountNo() {
		return bidderAccountNo;
	}
	public void setBidderAccountNo(String bidderAccountNo) {
		this.bidderAccountNo = bidderAccountNo;
	}
	@Column(name="AADHAAR_NO")
	public int getAadhaarNo() {
		return aadhaarNo;
	}
	public void setAadhaarNo(int aadhaarNo) {
		this.aadhaarNo = aadhaarNo;
	}
	@Column(name="PAN_NO")
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	
	@Column(name="LICENSE_NO")
	public String getLicenseNo() {
		return licenseNo;
	}
	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}

List<Bids> bids;
	
	@OneToMany(mappedBy="bidderinfo", fetch=FetchType.EAGER)
	public List<Bids> getBids() {
		return bids;
	}
	public void setBids(List<Bids> bids) {
		this.bids = bids;
	}

	



	@Override
	public String toString() {
		return "BidderInfo [bidderId=" + bidderId + ", bidderName=" + bidderName + ", bidderAddress=" + bidderAddress
				+ ", contactNo=" + contactNo + ", emailId=" + emailId + ", bidderAccountNo=" + bidderAccountNo
				+ ", aadhaarNo=" + aadhaarNo + ", panNo=" + panNo + ", licenseNo=" + licenseNo + "]";
	}



	
}

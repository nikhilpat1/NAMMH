package com.lti.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
@NamedQueries({
	@NamedQuery(name="maxBidId", query="select max(bidId) from Bids"),
	@NamedQuery(name="allUnapprovedBidsRequest", query="from Bids where status='Unapproved' order by bidAmount desc"),
})
@Entity
@Table(name="BIDDING_DETAILS")
public class Bids {
	
	private int bidId;
	
	private long bidAmount;
	
	private String status;
	
	private int sellId;

	public Bids(int bidId, long bidAmount, String status) {
		super();
		this.bidId = bidId;
		this.bidAmount = bidAmount;
		this.status = status;
	}

	public Bids() {
		super();
	}
	@Id
	@Column(name="BID_ID")
	public int getBidId() {
		return bidId;
	}

	public void setBidId(int bidId) {
		this.bidId = bidId;
	}
@Column(name="BID_AMOUNT")
	public long getBidAmount() {
		return bidAmount;
	}

	public void setBidAmount(long bidAmount) {
		this.bidAmount = bidAmount;
	}
	@Column(name="STATUS")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	private SellRequest sellrequest;
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="sell_id")
	
	public SellRequest getSellrequest() {
		return sellrequest;
	}
/*	@Column(name="sell_id")
	public int getSellId() {
		return sellId;
	}

	public void setSellId(int sellId) {
		this.sellId = sellId;
	}*/

	public void setSellrequest(SellRequest sellrequest) {
		this.sellrequest = sellrequest;
	}
	
	private BidderInfo bidderinfo;
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="bidder_id")
	public BidderInfo getBidderinfo() {
		return bidderinfo;
	}

	public void setBidderinfo(BidderInfo bidderinfo) {
		this.bidderinfo = bidderinfo;}

	@Override
	public String toString() {
		return "Bids [bidId=" + bidId + ", bidAmount=" + bidAmount + ", status=" + status + ", sellrequest="
				+ sellrequest + ", bidderinfo=" + bidderinfo + "]";
	}
		
	

	
}

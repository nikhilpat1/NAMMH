package com.lti.entities;
import java.sql.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@NamedQueries({
	@NamedQuery(name="maxSellId", query="select max(sellId) from SellRequest"),
	@NamedQuery(name="allUnapprovedSellRequest", query="from SellRequest where status='Unapproved'"),
	@NamedQuery(name="update", query="update SellRequest sReq set sReq.status=:status  where sReq.sellId=:sellId"),
	@NamedQuery(name="allActiveAuctions", query="from SellRequest where status='Approved'"),
	@NamedQuery(name="FilterActiveAuctions", query="from SellRequest sq where sq.status='Approved' and sq.cropdetails.cropName=:cropName"),
	@NamedQuery(name="currentSellRequest", query="from SellRequest where sellId=:sellId"),
	@NamedQuery(name="allDetails", query="from SellRequest where sellId=:sellId")
	
	
	//@NamedQuery(name="cropFilter", query="from ")
})
@Entity
@Table(name="Sell_Request")
public class SellRequest {
	private int sellId;
	private int cropId;
	private double baseValue;
	//private int farmerId;
	private Date startDate;
	private Date endDate;
	private String status;

	
	public SellRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	/*public SellRequest(int sellId, int cropId, double baseValue, int farmerId, Date startDate, Date endDate,
			String status) {
		super();
		this.sellId = sellId;
		this.cropId = cropId;
		this.baseValue = baseValue;
		this.farmerId = farmerId;
		this.startDate = startDate;
		this.endDate = endDate;
		this.status = status;
	}
*/
	public SellRequest(int sellId, double baseValue,/* int farmerId,*/ Date startDate, Date endDate,
			String status, CropDetails cropdetails) {
		super();
		this.sellId = sellId;
		//this.cropId = cropId;
		this.baseValue = baseValue;
		//this.farmerId = farmerId;
		this.startDate = startDate;
		this.endDate = endDate;
		this.status = status;
		this.cropdetails = cropdetails;
	}



	@Id
	@Column(name="SELL_ID")
	public int getSellId() {
		return sellId;
	}
	public void setSellId(int sellId) {
		this.sellId = sellId;
	}
	
	
	/*@Column(name="CROP_ID")
	public int getCropId() {
		return cropId;
	}

	public void setCropId(int cropId) {
		this.cropId = cropId;
	}*/

	@Column(name="BASE_VALUE")
	public double getBaseValue() {
		return baseValue;
	}
	public void setBaseValue(double baseValue) {
		this.baseValue = baseValue;
	}
	
/*	@Column(name="FARMER_ID")
	public int getFarmerId() {
		return farmerId;
	}
	public void setFarmerId(int farmerId) {
		this.farmerId = farmerId;
	}*/
	
	@Column(name="START_DATE")
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	
	@Column(name="END_DATE")
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	@Column(name="STATUS")
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	private CropDetails cropdetails;
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="CROP_ID")
	public CropDetails getCropdetails() {
		return cropdetails;
	}
	public void setCropdetails(CropDetails cropdetails) {
		this.cropdetails = cropdetails;
	}

@Override
	public String toString() {
		return "SellRequest [sellId=" + sellId +  ", baseValue=" + baseValue + /*", farmerId="
				+ farmerId + */", startDate=" + startDate + ", endDate=" + endDate + ", status=" + status
				+ ", cropdetails=" + cropdetails + "]";
	}
	


List<Bids> bids;
	
	@OneToMany(mappedBy="bidderinfo", fetch=FetchType.EAGER)
	public List<Bids> getBids() {
		return bids;
	}
	
	public void setBids(List<Bids> bids) {
		this.bids = bids;
	}

/*	@Override
	public String toString() {
		return "SellRequest [sellId=" + sellId + ", cropId=" + cropId + ", baseValue=" + baseValue + ", farmerId="
				+ farmerId + ", startDate=" + startDate + ", endDate=" + endDate + ", status=" + status + "]";
	}
	
	*/
	
	
	
	
}

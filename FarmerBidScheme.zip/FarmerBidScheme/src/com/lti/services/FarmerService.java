package com.lti.services;

import com.lti.entities.Bids;
import com.lti.entities.CropDetails;

import com.lti.entities.SellRequest;

import com.lti.exceptions.GenericException;

public interface FarmerService {
	public CropDetails addCropDetails(CropDetails cropDetails) throws GenericException;
	public Integer createNewCropId() throws GenericException;
	public Integer createNewSellId() throws GenericException;
	public SellRequest placeSellRequest(SellRequest sellRequest) throws GenericException;


}

package com.lti.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.daos.AdminDao;
import com.lti.daos.BidderDao;
import com.lti.entities.Bids;
import com.lti.entities.SellRequest;
import com.lti.exceptions.GenericException;
@Service
@Scope("singleton")
public class BidderServiceImpl implements BidderService{
	@Autowired
	private BidderDao dao;
	
	@Transactional(propagation=Propagation.REQUIRES_NEW)
	@Override
	public List<SellRequest> getActiveAuctions() throws GenericException {
		// TODO Auto-generated method stub
		return dao.getActiveAuctions();
	}
	//@Transactional(propagation=Propagation.REQUIRES_NEW)
	@Override
	public List<SellRequest> getFilterActiveAuctions(String str) throws GenericException {
		// TODO Auto-generated method stub
		return dao.getFilterActiveAuctions(str);
	}
	@Override
	public List<SellRequest> setBid(int sellId) throws GenericException {
		// TODO Auto-generated method stub
		return dao.setBid(sellId);
	}
	@Override
	public Integer createNewBidId() throws GenericException {
		// TODO Auto-generated method stub
		return dao.createNewBidId();
	}
	@Transactional(propagation=Propagation.REQUIRES_NEW)
	@Override
	public Bids addBids(Bids bids) throws GenericException {
		// TODO Auto-generated method stub
		return dao.addBids(bids);
	}
	@Transactional(propagation=Propagation.REQUIRES_NEW)
	@Override
	public SellRequest getSellRequestDetails(int sellId) throws GenericException {
		// TODO Auto-generated method stub
		return dao.getSellRequestDetails(sellId);
	}
	

}

package com.lti.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.daos.AdminDao;
import com.lti.entities.Bids;
import com.lti.entities.SellRequest;
import com.lti.exceptions.GenericException;
@Service
@Scope("singleton")
public class AdminServiceImpl implements AdminService{
	@Autowired
	private AdminDao dao;
	
	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public List<SellRequest> getUnapprovedSellRequest() throws GenericException {
		// TODO Auto-generated method stub
		return dao.getUnapprovedSellRequest();
	}

	@Override
	public SellRequest approveSellRequest(int sellId) throws GenericException {
		// TODO Auto-generated method stub
		return dao.approveSellRequest(sellId);
	}
	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public List<Bids> getUnapprovedBidsRequest() throws GenericException {
		// TODO Auto-generated method stub
		return dao.getUnapprovedBidsRequest();
	}
	@Transactional(propagation=Propagation.REQUIRED)
	@Override
	public Bids approveBidStatus(int bidId) throws GenericException {
		// TODO Auto-generated method stub
		return dao.approveBidStatus(bidId);
	}



}

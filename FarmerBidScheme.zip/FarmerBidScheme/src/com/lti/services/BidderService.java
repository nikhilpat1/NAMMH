package com.lti.services;

import java.util.List;

import com.lti.entities.Bids;
import com.lti.entities.SellRequest;
import com.lti.exceptions.GenericException;

public interface BidderService {
	List<SellRequest> getActiveAuctions() throws GenericException;
	List<SellRequest> getFilterActiveAuctions(String str) throws GenericException;
	List<SellRequest> setBid(int  sellId) throws GenericException;
	public Integer createNewBidId() throws GenericException;
	public Bids addBids(Bids bids) throws GenericException;
	public SellRequest getSellRequestDetails(int  sellId) throws GenericException;
}

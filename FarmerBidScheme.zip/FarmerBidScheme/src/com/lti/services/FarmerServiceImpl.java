package com.lti.services;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.daos.FarmerDao;
import com.lti.entities.Bids;
import com.lti.entities.CropDetails;
import com.lti.entities.SellRequest;
import com.lti.exceptions.GenericException;


@Service
@Scope("singleton")
public class FarmerServiceImpl implements FarmerService {
	@Autowired
	private FarmerDao dao;
	
	@Transactional(propagation=Propagation.REQUIRES_NEW)
	@Override
	public CropDetails addCropDetails(CropDetails cropDetails) throws GenericException {
		// TODO Auto-generated method stub
		System.out.println("in serviceImpl");
		System.out.println(cropDetails);
		return dao.insertCropDetails(cropDetails);
	}
	
	public Integer createNewCropId() throws GenericException{
		// TODO Auto-generated method stub
		return dao.createNewCropId();
	}

	@Override
	public Integer createNewSellId() throws GenericException {
		// TODO Auto-generated method stub
		return dao.createNewSellId();
	}
	@Transactional(propagation=Propagation.REQUIRES_NEW)
	@Override
	public SellRequest placeSellRequest(SellRequest sellRequest) throws GenericException {
		// TODO Auto-generated method stub
		System.out.println("in sell serviceImpl");
		System.out.println(sellRequest);
		return dao.insertSellDetails(sellRequest);
	}
	
}

package com.lti.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.lti.entities.BidderInfo;
import com.lti.entities.Bids;
import com.lti.entities.SellRequest;
import com.lti.exceptions.GenericException;
import com.lti.services.BidderService;

@Controller
public class BidderController {
	
	@Autowired
	private BidderService services;
	
	@RequestMapping("/enter.hr")
	public String goBidderHomePage() {	
		return "bidderHome";	
	}
	@RequestMapping("/viewActiveAuctions.hr")
	public ModelAndView getAllActiveAuctions() {	
		List<SellRequest> sellRequest  = null;
		ModelAndView mdv = new ModelAndView();
		mdv.setViewName("auctionList");
			try {
				sellRequest  = services.getActiveAuctions();
				System.out.println(sellRequest);
				mdv.addObject("list3", sellRequest);
			} catch (GenericException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			return mdv;
		
	}
	@RequestMapping("/filterActive.hr")
	public ModelAndView getFilterActiveAuctions(HttpServletRequest req) {	
		List<SellRequest> sellRequest  = null;
		ModelAndView mdv = new ModelAndView();
		String str1 = req.getParameter("cropName");
		mdv.setViewName("auctionList");
			try {
				sellRequest  = services.getFilterActiveAuctions(str1);
				System.out.println(sellRequest);
				mdv.addObject("list3", sellRequest);
			} catch (GenericException e) {
				
				e.printStackTrace();
			}	
			return mdv;
		
	}
	
	@RequestMapping("/PlaceBid.hr")
	public ModelAndView placeBid(HttpServletRequest request) {
		List<SellRequest> sellRequest1  = null;
		ModelAndView mnv =  new ModelAndView();
		String getSellid = request.getParameter("id");
		int sellNo = Integer.parseInt(getSellid);
		mnv.setViewName("placeBid");
			try {
				sellRequest1  = services.setBid(sellNo);
				System.out.println(sellRequest1);
				mnv.addObject("list3", sellRequest1);
			} catch (GenericException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			return mnv;
		
	}
	
	@RequestMapping(value = "/setBid.hr")
	  public ModelAndView addUser(HttpServletRequest request) {
		ModelAndView mnv =  new ModelAndView();
		Bids bids = new Bids();
		BidderInfo bidderinfo = new BidderInfo();
		SellRequest sellrequest = new SellRequest();
		
		mnv.setViewName("setBid");
		try {
			int id=services.createNewBidId();
			String getSellid = request.getParameter("sellId");
			int sellNo = Integer.parseInt(getSellid);
			System.out.println(sellNo);
			sellrequest = services.getSellRequestDetails(sellNo);
			bidderinfo.setBidderId("1");
			bidderinfo.setBidderAccountNo("42512223");
			bids.setBidId(id);
			String stra = request.getParameter("bidAmount");
			long bidAmount = Long.parseLong(stra);
			bids.setBidAmount(bidAmount);
			bids.setStatus("Unapproved");
			bids.setSellrequest(sellrequest);
			bids.setBidderinfo(bidderinfo);
			 System.out.println(bids);
			 services.addBids(bids);
		} catch (GenericException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	  return mnv;
	  }
	 
	
	
	
	
	
	
}

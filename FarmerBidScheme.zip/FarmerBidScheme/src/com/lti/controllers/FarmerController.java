package com.lti.controllers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.persistence.EntityTransaction;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.lti.daos.FarmerDaoImpl;
import com.lti.entities.CropDetails;
import com.lti.entities.FarmerInfo;
import com.lti.entities.SellRequest;
import com.lti.exceptions.GenericException;
import com.lti.services.FarmerService;
import com.lti.services.FarmerServiceImpl;

@Controller
public class FarmerController {
	@Autowired
	private FarmerService services;

	@RequestMapping("/AddCrops.hr")
	public String getAddCropPage() {	
	return "addCrops";
	}
	
	@RequestMapping("/addCrops.hr")
	public String addCropDetails(HttpServletRequest req) throws GenericException {
		System.out.println("Reached cropDetails");
		int farmerId =1;
		FarmerInfo farmerinfo = new FarmerInfo();
		farmerinfo.setFarmerId(1);
		/*farmerinfo.setFarmerName("Raju");
		farmerinfo.setFarmerAddress("Malad");
		farmerinfo.setFarmerAccountNo("536535236535");
		farmerinfo.setEmailId("raju@gmail.com");*/
		CropDetails cropdetails = new CropDetails();
		SellRequest sellRequest =new SellRequest();
		Integer id=services.createNewCropId();
		System.out.println(id);
		System.out.println(" Crop id created");
		cropdetails.setId(id);
		String str1 = req.getParameter("cropType");
		cropdetails.setCropType(str1);
		String str2 = req.getParameter("cropName");
		cropdetails.setCropName(str2);
		String str3 = req.getParameter("fertilizer");
		cropdetails.setFertilizerType(str3);
		String str4 = req.getParameter("soilPHCertificate");
		Double d1 = Double.parseDouble(str4);
		cropdetails.setSoilPh(d1);
		cropdetails.setFarmerinfo(farmerinfo);		
		Integer id1=services.createNewSellId();
		System.out.println(id1);
		System.out.println(" Sell id created");
		sellRequest.setSellId(id1);
		sellRequest.setCropdetails(cropdetails);
		String stra = req.getParameter("baseValue");
		Double d2 = Double.parseDouble(stra);
		sellRequest.setBaseValue(d2);
		
		String strb = req.getParameter("startDate");
		Date startDate= null;
		try {
			startDate = new SimpleDateFormat("yyyy-mm-dd").parse(strb);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		java.sql.Date sqlDate= new java.sql.Date(startDate.getTime());
		sellRequest.setStartDate(sqlDate);
		
		String strc = req.getParameter("startDate");
		Date startDate1= null;
		try {
			startDate1 = new SimpleDateFormat("yyyy-mm-dd").parse(strb);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		java.sql.Date sqlDate1= new java.sql.Date(startDate1.getTime());
		sellRequest.setStartDate(sqlDate1);
		
		sellRequest.setStatus("Unapproved");
		//sellRequest.set
		//sellRequest.setFarmerId(farmerId);
		
//		String str5 = req.getParameter("baseValue")
//		Double d1 = Double.parseDouble(str5);
		try {
			services.addCropDetails(cropdetails);
			System.out.println("adding cropDetails");
			services.placeSellRequest(sellRequest);
			System.out.println("adding sell Details");
		} catch (GenericException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return "admin";
	}
}

package com.lti.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lti.entities.Bids;
import com.lti.entities.CropDetails;
import com.lti.entities.SellRequest;
import com.lti.exceptions.GenericException;
import com.lti.services.AdminService;

@Controller
public class AdminController {
	@Autowired
	private AdminService services;
	
	@RequestMapping("/approveSell.hr")
	public ModelAndView approveSellRequest() {	
	List<SellRequest> sellRequest  = null;
	ModelAndView mdv = new ModelAndView();
	mdv.setViewName("success");
		try {
			sellRequest  = services.getUnapprovedSellRequest();

			System.out.println(sellRequest);
			mdv.addObject("list", sellRequest);
		} catch (GenericException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return mdv;
	}
	
	@RequestMapping("/approve.hr")
	public String updateStatus(HttpServletRequest request) {
	SellRequest sellRequest1  = null;
/*	ModelAndView mnv =  new ModelAndView();*/
	String getSellid = request.getParameter("id");
/*	mnv.setViewName("updateStatus");*/
	int sellNo = Integer.parseInt(getSellid);
	try {
		sellRequest1  = services.approveSellRequest(sellNo);
		System.out.println(sellRequest1);
		/*mnv.addObject("list1", sellRequest1);*/
	} catch (GenericException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
	return "bidderHome";
	}
	
	
	@RequestMapping("/approveBid.hr")
	public ModelAndView approveBidRequest() {	
	List<Bids> bids  = null;
	ModelAndView mdv = new ModelAndView();
	mdv.setViewName("approveBid");
		try {
			bids = services.getUnapprovedBidsRequest();
			System.out.println(bids);
			mdv.addObject("list5", bids);
		
		} catch (GenericException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return mdv;
	}
	
	@RequestMapping("/approveBidRequest.hr")
	public String approveBidStatus(HttpServletRequest request) {
	Bids bids  = null;
	String getBidId = request.getParameter("id");
	int bidNo = Integer.parseInt(getBidId);
	try {
		bids  = services.approveBidStatus(bidNo);
		System.out.println(bids);
		/*mnv.addObject("list1", sellRequest1);*/
	} catch (GenericException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
	return "adminSuccess";
	}

}

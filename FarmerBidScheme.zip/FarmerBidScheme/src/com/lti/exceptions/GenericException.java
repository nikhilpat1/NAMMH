package com.lti.exceptions;

public class GenericException extends Exception {
	public GenericException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}
	public GenericException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
